A dynamic page that displays the movies of th genre which the user picked
